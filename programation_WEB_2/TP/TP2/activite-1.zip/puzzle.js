
document.querySelector(".plateau").
    innerHTML+='<div class="ball green"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball red"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball orange"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball yellow"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball blue"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball green"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball yellow"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball orange"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball green"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball "></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball orange"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball yellow"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball red"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball red"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball orange"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball "></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball "></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball red"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball green"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball orange"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball yellow"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball orange"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball red"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball green"></div>';
document.querySelector(".plateau").
    innerHTML+='<div class="ball blue"></div>';